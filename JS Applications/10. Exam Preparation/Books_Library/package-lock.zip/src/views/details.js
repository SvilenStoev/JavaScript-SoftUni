import { deleteItem, getById } from '../api/data.js';
import { getUserData } from '../util.js';
import { html } from '../lib.js';

const detailsTemplate = (item, isOwner, onDelete) => html`
<section id="details-page" class="details">
    <div class="book-information">
        <h3>${item.title}</h3>
        <p class="type">Type: ${item.type}</p>
        <p class="img"><img src="${item.imageUrl}"></p>
        <div class="actions">
            ${isOwner ? html`<a class="button" href="/edit/${item._id}">Edit</a>
            <a @click=${onDelete} class="button" href="javascript:void(0)">Delete</a>`
            : null}

            <!-- Bonus -->
            <!-- Like button ( Only for logged-in users, which is not creators of the current book ) -->
            <a class="button" href="#">Like</a>

            <!-- ( for Guests and Users )  -->
            <div class="likes">
                <img class="hearts" src="/images/heart.png">
                <span id="total-likes">Likes: 0</span>
            </div>
            <!-- Bonus -->
        </div>
    </div>
    <div class="book-description">
        <h3>Description:</h3>
        <p>${item.description}</p>
    </div>
</section>`;

export async function detailsPage(ctx) {
    const item = await getById(ctx.params.id);

    const userData = getUserData();
    const isOwner = userData && item._ownerId == userData.id;

    ctx.render(detailsTemplate(item, isOwner, onDelete));

    async function onDelete() {
        const choise = confirm('Are you sure you want to delete this item forever?');

        if (choise) {
            await deleteItem(ctx.params.id);
            ctx.page.redirect('/books');
        }
    }
}